Monday:
  Breakfast (7:30am): Oatmeal with berries and honey
  Lunch (11:30am): Salad with grilled chicken
  Dinner (6:30pm): Spaghetti with homemade pasta and meatballs
  Snacks (3pm): Apple slices with almond butter
  GroceryShopping:
    - Whole grain oats
    - Fresh berries (strawberries, blueberries)
    - Honey
    - Chicken breast
    - Mixed greens
    - Cherry tomatoes
    - Ground beef
    - Italian sausage
    - Pasta flour
    - Eggs
    - Parmesan cheese
    - Apples
    - Almond butter
  Things:
    - Organize new office
    - Portion and freeze meatballs
    - Find Dune Imperium game

Tuesday:
  Breakfast (7:30am): Scrambled eggs and toast
  Lunch (11:30am): Leftover meatballs on salad
  Dinner (6:30pm): Mini pizzas on english muffins
  Snacks (3pm): Yogurt with granola
  Things:
    - Organize new office
    - Play Dune Imperium
    - Go to False Idol

Wednesday:
  Breakfast (7:30am): Greek yogurt parfait
  Lunch (11:30am): Restaurant at work
  Dinner (6:30pm): Leftovers from Monday
  Snacks (3pm): Trail mix
  Things:
    - Organize new office
    - Play Dune Imperium

Thursday:
  Breakfast (7:30am): Smoothie bowl
  Lunch (11:30am): Meal prep from freezer
  Dinner (6:30pm): Order takeout before DnD
  Snacks (3pm): String cheese and crackers
  Things:
    - Organize new office
    - 6:30 PM: DnD Player session at Gen X Comics
    - 7:45 PM: DnD DM session at Gen X Comics

Friday:
  Breakfast (7:30am): Pancakes
  Lunch (11:30am): Turkey sandwich
  Dinner (6:30pm): Stir fry with rice
  Snacks (3pm): Hummus and veggies
  Things:
    - Clean up office
    - Prep for weekend

Saturday:
  Breakfast (7:30am): Breakfast burrito
  Lunch (11:30am): Grilled cheese and soup
  Dinner (6:30pm): BBQ night
  Snacks (3pm): Popcorn
  Things:
    - Meal prep for next week
    - Board game night

Sunday:
  Breakfast (7:30am): French toast
  Lunch (11:30am): Leftover BBQ
  Dinner (6:30pm): Light soup and salad
  Snacks (3pm): Dark chocolate
  Things:
    - Plan next week
    - Grocery shop for next week
    - Relax and recharge
